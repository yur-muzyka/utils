<?php

$facebook = new Facebook(array(
  'appId'  => '1857159771091405',
  'secret' => 'bd0f0afa7544f11a00d0a7838037628f',
  'cookie' => true
));

?>
