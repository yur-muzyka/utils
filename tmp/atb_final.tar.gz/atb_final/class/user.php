<?php

class User {

    public $id;
    public $soc;
    public $uid;
    public $firstname;
    public $lastname;
    public $email;
    public $img;

    function save() {
        if ($this->is_new()) {
            $this->create();
            return mysql_insert_id();
        } else {
            $this->update();
            return $this->get_id_by_email();
        }
    }

    function is_new() {
        $query = 'SELECT id FROM users WHERE email="' . $this->email . '"';
        $num_rows = mysql_num_rows(mysql_query($query));
        if ($num_rows == 0) {
            return true;
        }
        return false;
    }

    function create() {
        $query = 'INSERT INTO users
                  VALUES(0, "' . $this->soc . '", "' . $this->uid .'", "' . $this->firstname . '",
                  "' . $this->lastname . '", "' . $this->email . '", "' . $this->img . '");'; 
        mysql_query($query);
    }

    function update() {
        $query = 'UPDATE users
                  SET  soc       ="' . $this->soc .       '",
                       uid       ="' . $this->uid .       '",
                       firstname ="' . $this->firstname . '",
                       lastname  ="' . $this->lastname .  '",
                       email     ="' . $this->email .     '",
                       img       ="' . $this->img .       '"
                  WHERE email    ="' . $this->email .     '";';
        mysql_query($query) or die(mysql_error());
    }

    function copy_img_from_url($url, $user_id) {
        $ext = $this->get_file_extension($url);
        $filename = $user_id . '.' . $ext;
        copy($url, 'upload/' . $filename);
        return $filename;
    }

    function get_file_extension($filename) {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        return $ext;
    }

    function get_id_by_email() {
        $query = 'SELECT id FROM users WHERE email="' . $this->email . '"';
        $id = mysql_result(mysql_query($query), 0);
        return $id;
    }

    static function get_all_users_count() {
        $query = 'SELECT id FROM users';
        $num_rows = mysql_num_rows(mysql_query($query));
        return $num_rows;
    }
    
    static function find($id) {
        $query = 'SELECT * FROM users WHERE id="' . $id . '"';
        $user_array = mysql_fetch_assoc(mysql_query($query));

        $user = new User;
        $user->id = $user_array['id'];
        $user->soc = $user_array['soc'];
        $user->uid = $user_array['uid'];
        $user->firstname = $user_array['firstname'];
        $user->lastname = $user_array['lastname'];
        $user->email = $user_array['email'];
        $user->img = $user_array['img'];
        return $user;
    }

    static function find_by_fb_uid($uid) {
        $query = 'SELECT * FROM users WHERE uid="' . $uid . '"';
        $user_array = mysql_fetch_assoc(mysql_query($query));

        $user = new User;
        $user->id = $user_array['id'];
        $user->soc = $user_array['soc'];
        $user->uid = $user_array['uid'];
        $user->firstname = $user_array['firstname'];
        $user->lastname = $user_array['lastname'];
        $user->email = $user_array['email'];
        $user->img = $user_array['img'];
        return $user;
    }

    static function remove_img($filename) {
        unlink ('upload/' . $filename);
    }
}

?>
