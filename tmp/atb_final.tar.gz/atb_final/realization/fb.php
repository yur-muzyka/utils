<?php

class Fb {

    public function get_soc_name() {
        return 'fb';
    }

    public function get_account_photo_url($user_uid) {
        $account_photo_hash = 'https://graph.facebook.com/' . $user_uid . '/picture?width=200&height=200&redirect=false';
        $account_photo_obj = json_decode(file_get_contents($account_photo_hash));
        $account_photo_url = $account_photo_obj->data->url;
        return $account_photo_url;
    }

    public function get_user_obj($user_uid) {
        global $facebook;
        $user_obj = $facebook->api('/' . $user_uid);
        return $user_obj;
    }
}
