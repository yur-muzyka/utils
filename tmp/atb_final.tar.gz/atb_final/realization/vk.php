<?php

class Vk {
    public $client_id ='3903522'; // ID приложения  
    public $client_secret = 'J0pq5svoqeDXM2JdI64J'; // Защищённый ключ
    public $redirect_uri = 'http://fortesting.edgework.com.ua/muzyka/atb/'; // Адрес сайта

    public function get_soc_name() {
        return 'vkontakte';
    }

    public function get_login_link() {

        $url = 'http://oauth.vk.com/authorize';
        $params = array(
            'client_id'     => $this->client_id,
            'redirect_uri'  => $this->redirect_uri,
            'scope'         => 'friends,photos,email,offline,wall',
            'response_type' => 'code'
        );

        //$login = '<a href="' . $url . '?' . urldecode(http_build_query($params)) . '">login</a>';        
        $login = $url . '?' . urldecode(http_build_query($params));        

        return $login;
    }

    public function get_account_photo_url() {
        return $_SESSION['vk_user']['photo_big'];
    }

    public function get_user_obj() {
        $ses = $_SESSION['vk_user'];
        $obj = array();
        $obj['first_name'] = $ses['first_name'];
        $obj['last_name'] = $ses['last_name'];
        //$obj['email'] = $ses['mail'];
        $obj['img'] = $ses['photo_big'];
        return $obj;
    }
}

?>
