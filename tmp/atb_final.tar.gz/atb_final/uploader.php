<?php

require "config.php";
require "class/db_connect.php";
require "class/user.php";
require "class/templ.php";
require_once "class/fb_sdk/base_facebook.php";
require_once "class/fb_sdk/facebook.php";
require "class/facebook.php";
require "class/simple_image.php";



if ($_POST['dimensions'] == 'get') {
    $id = $_POST['id'];
    $user = User::find($id);
    $sim = new SimpleImage();
    $sim->load('upload/' . $user->img);
    echo '{"original_width": "' . $sim->getWidth() . '", "original_height": "' . $sim->getHeight() . '"}';
    die();
}

if ($_POST['file_upload'] == 'move_to_upload') {
    $tmp_file = $_POST['tmp_filename'];
    $id = $_POST['id'];
    $extension = pathinfo($tmp_file, PATHINFO_EXTENSION);
    $new_image_filename = $id . '.' . $extension;

    $user = User::find($id);
    User::remove_img($user->img);

    copy('upload_tmp/' . $tmp_file, 'upload/' . $new_image_filename);
    unlink('upload_tmp/' . $tmp_file);


    $user->img = $new_image_filename;
    $user->save();

    //$sim = new SimpleImage();
    //$sim->load('upload/' . $new_image_filename);
    //echo '{"original_width": "' . $sim->getWidth() . '", "original_height": "' . $sim->getHeight() . '"}';

    die();
}


$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["files"]["name"][0]);
$extension = end($temp);

if ((($_FILES["files"]["type"][0] == "image/gif")
    || ($_FILES["files"]["type"][0] == "image/jpeg")
    || ($_FILES["files"]["type"][0] == "image/jpg")
    || ($_FILES["files"]["type"][0] == "image/pjpeg")
    || ($_FILES["files"]["type"][0] == "image/x-png")
    || ($_FILES["files"]["type"][0] == "image/png"))
    && ($_FILES["files"]["size"][0] < 5000000)
    && in_array($extension, $allowedExts)) {

    if ($_FILES["files"]["error"][0] > 0) {
        echo "Return Code: " . $_FILES["files"]["error"] . "<br>";
    } else {
        move_uploaded_file($_FILES["files"]["tmp_name"][0], "upload_tmp/" . $_FILES["files"]["name"][0]);
        echo '{"status": "success", "tmp_filename": "' . $_FILES["files"]["name"][0] . '"}';
    }
} else {
    echo "Invalid file";
}

?>
