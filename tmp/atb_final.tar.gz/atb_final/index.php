<?php

require "config.php";
require "class/db_connect.php";
require "class/user.php";
require "class/templ.php";
require_once "class/fb_sdk/base_facebook.php";
require_once "class/fb_sdk/facebook.php";
require "class/facebook.php";
require "class/simple_image.php";
require "class/square_crop.php";
require "realization/fb.php";
require "realization/vk.php";

if ($_POST['set_social']) {
    $_SESSION['social'] = $_POST['set_social'];
    die();
}

if ($_POST['get'] == 'vk_user') {
    echo '{"uid": "' . $_SESSION['vk_user']['uid'] . '"}';
    die();
}

if ($_SESSION['social'] == 'facebook') {
    $real = new Fb();
} elseif ($_SESSION['social'] == 'vkontakte') {
    $real = new Vk();
}

// first post after login
if ($_POST['show_face'] == 'create') {
    $user_uid = $_POST['uid'];

    $account_photo_url = $real->get_account_photo_url($user_uid);

    $user_obj = $real->get_user_obj($user_uid);

    $user = new User;
    $user->soc = $real->get_soc_name();
    $user->uid = $user_uid;
    $user->firstname = $user_obj['first_name'];
    $user->lastname = $user_obj['last_name'];
    $user->email = $user_obj['email'];
    $user->img = $account_photo_url;
    $user_id = $user->save();
    $user->img = $user->copy_img_from_url($account_photo_url, $user_id);
    $user->save();
    show_face_template($user_id, $user->img);
}

if ($_POST['albums'] == 'get') {
    $albums = $facebook->api('/me/albums');

    foreach ($albums['data'] as $album) {
        $photos = $facebook->api('/' . $album['id'] . '/photos/');
        $photos_array[] = $photos['data'];
    }

    foreach ($photos_array as $photo) {
        foreach ($photo as $phot) {
            //echo '<img src="' . $phot['images'][0]['source'] . '">\n';
            $photos_arr[] = $phot['images'][0]['source'];
        }
    }

    $count = 0;
    foreach ($photos_arr as $phot) {
        $photos_exp[] = $phot;
        $count++;
        if ($count == 18) break;
    }
    $tpl = new Template('choose_photo.tpl');
    $tpl->set('photos', $photos_exp);
    echo $tpl;
    die();
}

if ($_POST['video'] == 'start') {
    $id = $_POST['user_id'];
    $user = User::find($id); // user
    $uid = $_POST['uid'];
    $token = $_POST['token'];

    $facebook->setAccessToken($token);
    $albums = $facebook->api('/me/albums');

    $dirname = 'export/' . $user->id . '/';

    // b-remove dir
    if (!file_exists($dirname)) {
        mkdir("export/" . $user->id);
    } else {
        remove_dir($dirname);
        mkdir("export/" . $user->id);
    }
    // e-remove dir
    
    foreach ($albums['data'] as $album) {
        $photos = $facebook->api('/' . $album['id'] . '/photos/');
        $photos_array[] = $photos['data'];
    }

    foreach ($photos_array as $photo) {
        foreach ($photo as $phot) {
            //echo '<img src="' . $phot['images'][0]['source'] . '">\n';
            $photos_arr[] = $phot['images'][0]['source'];
        }
    }

    $count = 0;
    foreach ($photos_arr as $phot) {
        $photos_exp[] = $phot;
        $count++;
        if ($count == 4) break;
    }

    $count = 10;
    $sim = new SimpleImage();
    $cr = new square_crop();
    foreach ($photos_exp as $photo) {
        $cr->source_image = $photo;
        $cr->new_image_name = $count;
        $cr->save_to_folder = 'export/' . $user->id . '/';
        $result = $cr->crop();

        if ($result != 'already square') {
            $sim->load('export/' . $user->id . '/' . $count . '.jpg');
            $sim->resize(80, 80);
            $sim->save('export/' . $user->id . '/' . $count . '.png', IMAGETYPE_PNG);
            unlink('export/' . $user->id . '/' . $count . '.jpg');
            $count++;
        } else {
            $sim->load($photo);
            $sim->resize(80, 80);
            $sim->save('export/' . $user->id . '/' . $count . '.png', IMAGETYPE_PNG);
            $count++;
        }
    }
    // $photots_exp   -   4 photo;
    
    $friends = $facebook->api('/me/friends', 
        array('limit' => 2,));
                                                
    foreach ($friends['data'] as $friend) {
        $friends_arr[] = $facebook->api('/' . $friend['id']);
    }

    foreach ($friends_arr as $key => $friend) {
        $photo_url = get_account_photo_url($friend['id']);
        $friends_arr[$key]['photo_url'] = $photo_url;
    }


    foreach ($photos_array as $photo) {
        foreach ($photo as $phot) {
            foreach ($phot['images'] as $pho) {
                //echo '<img src="' . $pho['source'] . '">\n';
            }
        }
    }

    // b-input user name on transpaernt png

    putenv('GDFONTPATH=' . realpath('.'));
    $font_path = 'time';
    $font_size = 28;
    $text = $user->firstname . ' ' . $user->lastname;
    $img_width = 446;
    $img_height = 36;
    $background = imagecreatetruecolor($img_width,$img_height);
    $font_color = imagecolorallocate($background, 0, 0, 0);
    $black = imagecolorallocate($background, 0, 0, 0);

    // b-make transparent
    imagealphablending($background, false);
    $transparency = imagecolorallocatealpha($background, 0, 0, 0, 127);
    imagefill($background, 0, 0, $transparency);
    imagesavealpha($background, true);
    // e-make transparent

    $p = imagettfbbox($font_size,0,$font_path,$text);
    $txt_width=$p[2]-$p[0];
    $txt_height=$p[1]-$p[7]; // just in case you need it

    $x = ($img_width - $txt_width) / 2;
    $y = 30;
    imagettftext($background, $font_size, 0, $x, $y, $font_color, $font_path, $text);

    //header('Content-Type: image/png');

    imagepng($background, 'export/' . $user->id . '/1.png');
    imagedestroy($background);
    // e-input user name on transpaerent png

    // b-input 2 boys and me on transparent png ///////////////
    putenv('GDFONTPATH=' . realpath('.'));
    $friends_and_me = array();
    $friends_and_me = array_merge(array(0 => array('name' => $user->firstname . ' ' . $user->lastname)), $friends['data']);

    $font_path = 'time';
    $font_size = 28;
    $img_width = 276;
    $img_height = 134;
    $background = imagecreatetruecolor($img_width,$img_height);
    $font_color = imagecolorallocate($background, 0, 0, 0);
    $black = imagecolorallocate($background, 0, 0, 0);

    // b-make transparent
    imagealphablending($background, false);
    $transparency = imagecolorallocatealpha($background, 0, 0, 0, 127);
    imagefill($background, 0, 0, $transparency);
    imagesavealpha($background, true);
    // e-make transparent

    $y = 30;
    foreach ($friends_and_me as $friend) {
        $text = $friend['name'];
        $p = imagettfbbox($font_size,0,$font_path,$text);
        $txt_width=$p[2]-$p[0];
        $txt_height=$p[1]-$p[7]; // just in case you need it

        $x = ($img_width - $txt_width) / 2;
        imagettftext($background, $font_size, 0, $x, $y, $font_color, $font_path, $text);
        $y += 40;
    }

    imagepng($background, $dirname . '/5.png');
    imagedestroy($background);
    // b-input 2 boys and me on transparent png ////////////////////
    
    // b-make 3 thumbs: friend, me, friend
    // convert from jpg to png
    //echo '<img src="upload/' . $user->img . '">';
    //die();
    //imagepng(imagecreatefromstring(file_get_contents('upload/' . $user->img)), 'export/' . $user->id . '/7.png');
    //copy('upload/' . $user->img, 'export/' . $user->id . '/7.png');

    $sim = new SimpleImage();
    $sim->load('upload/' . $user->img);
    $sim->resize(75, 75);
    $sim->save('export/' . $user->id . '/7.png', IMAGETYPE_PNG);

    $sim->load('upload/' . $user->img);
    $sim->resize(80, 80);
    $sim->save('export/' . $user->id . '/9.png', IMAGETYPE_PNG);

    $filename = 6;
    foreach ($friends['data'] as $friend) {
        $sim->load(get_account_photo_url($friend['id']));
        $sim->resize(75, 75);
        $sim->save('export/' . $user->id . '/' . $filename . '.png', IMAGETYPE_PNG);
        $filename += 2;
    }

    $t = new Template('video.tpl');
    $t->set('id', $user->id);
    echo $t;

    die();
}

if ($_POST['crop_ready'] == 'true') {
    $params = $_POST['img_params'];
    $img = $_POST['img'];
    $preview_width = $_POST['preview_width'];
    $preview_height = $_POST['preview_height'];
    $new_width = 202;
    $new_height = 202;
    $original_dimensions = json_decode($_POST['original_dimensions']);

    $krop_koef = get_crop_koef($original_dimensions->original_width, $preview_width);
    $jpeg_quality = 90;

    $src = $img;
    $img_r = imagecreatefromjpeg($src);
    $dst_r = ImageCreateTrueColor( $new_width, $new_height );
    imagecopyresampled($dst_r,$img_r, 0, 0, $params['x'] * $krop_koef, $params['y'] * $krop_koef,
        $new_width, $new_height, $params['w'] * $krop_koef, $params['h'] * $krop_koef);

    //header('Content-type: image/jpeg');
    imagejpeg($dst_r, $img, $jpeg_quality);
    die();
}

if ($_POST['show_face'] == 'update') {
    $user_id = $_POST['user_id'];
    $user = User::find($user_id);
    show_face_template($user_id, $user->img);
}

function show_face_template($user_id, $user_img) {
    $face = new Template('face.tpl');
    $face->set('account_photo_url', $user_img);
    $face->set('id', $user_id);
    echo $face;
    die();
}

function get_account_photo_url($user_uid) {
    $account_photo_hash = 'https://graph.facebook.com/' . $user_uid . '/picture?width=200&height=200&redirect=false';
    $account_photo_obj = json_decode(file_get_contents($account_photo_hash));
    $account_photo_url = $account_photo_obj->data->url;
    return $account_photo_url;
}

function rrmdir($dir) { 
    if (is_dir($dir)) { 
        $objects = scandir($dir); 
        foreach ($objects as $object) { 
            if ($object != "." && $object != "..") { 
                if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object); 
            } 
        } 
        reset($objects); 
        rmdir($dir); 
    } 
}

function remove_dir($dir) {
    foreach(glob($dir . '/*') as $file) {
        if(is_dir($file))
            rrmdir($file);
        else
            unlink($file);
    }
    rmdir($dir);
}

function get_crop_koef($original_width, $real_width) {
    $koef = $original_width / $real_width;
    return $koef;
}

//b-delete all cookies
//if (isset($_SERVER['HTTP_COOKIE'])) {
    //$cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    //foreach($cookies as $cookie) {
        //$parts = explode('=', $cookie);
        //$name = trim($parts[0]);
        //setcookie($name, '', time()-1000);
        //setcookie($name, '', time()-1000, '/');
    //}
//}
//e-delete all cookies

$main = new Template('main.tpl');
$vk = new Vk();
$main->set('vk_login_link', $vk->get_login_link());

$all_users_count = User::get_all_users_count();
$main->set('all_users_count', $all_users_count);
echo $main;

//b-vk login
if (isset($_GET['code'])) {
    $params = array(
        'client_id' => $vk->client_id,
        'client_secret' => $vk->client_secret,
        'code' => $_GET['code'],
        'redirect_uri' => $vk->redirect_uri
    );

    $token = json_decode(file_get_contents('https://oauth.vk.com/access_token' . '?' . urldecode(http_build_query($params))), true);

    if (isset($token['access_token'])) {
        $params = array(
            'uids'         => $token['user_id'],
            'fields'       => 'uid,first_name,last_name,screen_name,sex,bdate,photo_big',
            'access_token' => $token['access_token']
        );

        $userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get' . '?' . urldecode(http_build_query($params))), true);
        if (isset($userInfo['response'][0]['uid'])) {
            $userInfo = $userInfo['response'][0];
            $result = true;
        }

        $_SESSION['vk_user'] = $userInfo;

        ?>
            <script>
                vk_login("<?php echo $userInfo['uid'] ?>");
            </script>
        <?php
    }
}    
//e-vk login

?>
