<html>
    <head></head>
    <body>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>

        <div id="fb-root"></div>

        <script>
            window.fbAsyncInit = function() {
                // init the FB JS SDK
                FB.init({
                  appId      : '1857159771091405',                   // App ID from the app dashboard
                  channelUrl : 'http://fortesting.edgework.com.ua/muzyka/atb/', // Channel file for x-domain comms
                  status     : true,                                 // Check Facebook Login status
                  xfbml      : true,                                  // Look for social plugins on the page
                  cookie     : true, // enable cookies to allow the server to access the session
                });

                FB.login(function(response) {
                }, {scope: 'email,user_likes,user_photos,friends_photos,publish_stream'});
            };

            (function(d, s, id){
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) {return;}
                js = d.createElement(s); js.id = id;
                js.src = "//connect.facebook.net/en_US/all.js";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
    </body>
</html>

<?php

require "config.php";
require "class/db_connect.php";
require "class/user.php";
require "class/templ.php";
require_once "class/fb_sdk/base_facebook.php";
require_once "class/fb_sdk/facebook.php";
require "class/facebook.php";
require "class/simple_image.php";


$facebook = new Facebook(array(
  'appId'  => '1857159771091405',
  'secret' => 'bd0f0afa7544f11a00d0a7838037628f',
  'cookie' => true
));

$uid = $facebook->getUser();
if (!$uid) {
    die();
}

    $albums = $facebook->api('/me/albums');
echo "<pre>";
$dd = $albums['data'][0]['id'];

$dd = 100006286052481;
 if($dd)    
     $fql            =   'SELECT pid,src_big,owner,link,position,created,caption,src      FROM photo WHERE aid="'.$dd.'" ORDER BY created DESC LIMIT 0,6';

            $param  =   array(
            'method'    => 'fql.query',
            'query'     => $fql,
            'callback'  => ''
        );
        $fqlResult   =   $facebook->api($param);
    var_dump($fqlResult);
die();

    foreach ($albums['data'] as $album) {
        $photos = $facebook->api('/' . $album['id'] . '/photos');
        $photos_array[] = $photos['data'];
    }

    foreach ($photos_array as $photo) {
        foreach ($photo as $phot) {
            //echo '<img src="' . $phot['images'][0]['source'] . '">\n';
            $photos_arr[] = $phot['images'][0]['source'];
        }
    }

    var_dump($photos_arr); die();
    $count = 0;
    foreach ($photos_arr as $phot) {
        $photos_exp[] = $phot;
        $count++;
        if ($count == 18) break;
    }
    $tpl = new Template('choose_photo.tpl');
    $tpl->set('photos', $photos_exp);
    echo $tpl;
    die();                           


function get_photos_by_album_id($album_id){

 if($album_id)
     $fql            =   'SELECT pid,src_big,owner,link,position,created,caption,src      FROM photo WHERE aid="'.$album_id.'" ORDER BY created DESC LIMIT 0,6';

            $param  =   array(
            'method'    => 'fql.query',
            'query'     => $fql,
            'callback'  => ''
        );
        $fqlResult   =   $facebook->api($param);
    return $fqlResult;

 }



echo '<img src="upload/' . $user->img . '">';
