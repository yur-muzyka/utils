<?php

define('REDIRECT_URI', 'http://fortesting.edgework.com.ua/muzyka/atb/');
define('DB_HOST', 'localhost');
define('DB_NAME', 'fortesti_atb');
define('DB_USER', 'fortesti_atb');
define('DB_PASS', 'qwertyu');

?>
