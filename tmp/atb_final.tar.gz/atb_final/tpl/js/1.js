$(document).ready(function(){
      // alert('ddd');
	   /* $("#scroll").mCustomScrollbar({
	    }); */

    $('.list-photo div ul li').click(function(){
			alert('d');
            $(this).addClass('active');
			/*if($(this).hasClass('active')) {
				$(this).removeClass('active');
				}
			else  {
				$(this).addClass('active');*/
			})

});